package com.gt.matcher.stringmatch;

public class WordMatchDetail {
	public String mainWord;
	public String compareWord;
	public boolean isMatch;
	
	public String getMainWord() {
		return mainWord;
	}
	public void setMainWord(String mainWord) {
		this.mainWord = mainWord;
	}
	public String getCompareWord() {
		return compareWord;
	}
	public void setCompareWord(String compareWord) {
		this.compareWord = compareWord;
	}
	public boolean isMatch() {
		return isMatch;
	}
	public void setMatch(boolean isMatch) {
		this.isMatch = isMatch;
	}
}
